# webassassin
spam sms iran
pkg install python2
pip install requiests
pip install colorama


git clone https://github.com/hashashin-tracuer/webassassin.git
